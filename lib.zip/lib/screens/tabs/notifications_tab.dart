import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../widgets/vehicle_picker.dart';

import '../../providers/fleet_provider.dart';
import '../../providers/maintenance_provider.dart';

class NotificationsTab extends StatelessWidget {
  const NotificationsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final fleet = context.watch<FleetProvider>();
    final maint = context.watch<MaintenanceProvider>();

    final messages = <String>[];
    for (final v in fleet.vehicles) {
      messages.addAll(maint.dueMessagesForVehicle(v));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Thông báo'),
        actions: const [VehiclePicker(), SizedBox(width: 8)],
      ),
      body: messages.isEmpty
          ? const Center(child: Text('Chưa có thông báo bảo dưỡng.'))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: messages.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) => ListTile(
                leading: const Icon(Icons.notifications_active),
                title: Text(messages[i]),
              ),
            ),
    );
  }
}
