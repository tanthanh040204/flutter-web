import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../widgets/vehicle_picker.dart';

import '../../providers/fleet_provider.dart';
import '../../providers/trip_provider.dart';

class MoreTab extends StatelessWidget {
  const MoreTab({super.key});

  @override
  Widget build(BuildContext context) {
    final fleet = context.watch<FleetProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Thông tin khác'),
        actions: const [VehiclePicker(), SizedBox(width: 8)],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 10),
          ListTile(
            leading: const Icon(Icons.check_box_outline_blank),
            title: const Text('Số xe đang quản lí'),
            trailing: Text('${fleet.vehicles.length}'),
          ),
        ],
      ),
    );
  }
}
