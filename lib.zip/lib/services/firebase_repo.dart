import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:latlong2/latlong.dart';

import '../models/maintenance_item.dart';
import '../models/trip.dart';
import '../models/vehicle.dart';
import '../models/daily_stat.dart';

import '../models/history_route.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:latlong2/latlong.dart';

class FirebaseRepo {
  FirebaseRepo._();
  static final FirebaseRepo instance = FirebaseRepo._();

  final Map<String, Vehicle> _localVehicles = <String, Vehicle>{};
  final StreamController<List<Vehicle>> _localVehiclesCtl =
      StreamController<List<Vehicle>>.broadcast();

  bool get _isReady => Firebase.apps.isNotEmpty;

  bool get _shouldUseLocalMode {
    if (!_isReady) return true;
    try {
      final options = Firebase.app().options;
      return options.projectId.trim().toLowerCase() == 'demo-project';
    } catch (_) {
      return true;
    }
  }

  FirebaseFirestore? get _db {
    if (!_isReady || _shouldUseLocalMode) return null;
    try {
      return FirebaseFirestore.instance;
    } catch (_) {
      return null;
    }
  }

  CollectionReference<Map<String, dynamic>>? get _vehicles =>
      _db?.collection('vehicles');

  List<Vehicle> _sortedLocalVehicles() {
    final list = _localVehicles.values.toList();
    list.sort((a, b) => _vehicleSortKey(a.id).compareTo(_vehicleSortKey(b.id)));
    return list;
  }

  void _emitLocalVehicles() {
    if (_localVehiclesCtl.isClosed) return;
    _localVehiclesCtl.add(_sortedLocalVehicles());
  }

  //
  Future<void> deleteHistoryRoute(String vehicleId, String routeId) async {
    final vehicles = _vehicles;
    if (vehicles == null) {
      throw StateError('Firestore chưa được khởi tạo.');
    }

    await vehicles
        .doc(vehicleId)
        .collection('history_routes')
        .doc(routeId)
        .delete();
  }

  //
  Future<void> saveVehicle(Vehicle v) async {
    final vehicles = _vehicles;
    if (vehicles == null) {
      _localVehicles[v.id] = v;
      _emitLocalVehicles();
      return;
    }

    try {
      await vehicles.doc(v.id).set({
        'id': v.id,
        'name': v.name,
        'batteryPercent': v.batteryPercent,
        'isLocked': v.isLocked,
        'isRunning': v.isRunning,
        'totalKm': v.totalKm,
        'temp': v.temp,
        'hum': v.hum,
        'dust': v.dust,
        'lastLocation': {
          'lat': v.lastLocation.latitude,
          'lon': v.lastLocation.longitude,
          'name': v.name,
          'totalKm': v.totalKm,
        },
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {
      _localVehicles[v.id] = v;
      _emitLocalVehicles();
    }
  }

  Future<String> createVehicle({
    required String name,
    int batteryPercent = 80,
    double totalKm = 0,
    LatLng? lastLocation,
  }) async {
    final nextId = await getNextVehicleId();
    final location = lastLocation ?? const LatLng(21.0287, 105.8522);

    await saveVehicle(
      Vehicle(
        id: nextId,
        name: name,
        batteryPercent: batteryPercent.clamp(0, 100).toInt(),
        isLocked: true,
        isRunning: false,
        totalKm: totalKm,
        temp: 0,
        hum: 0,
        dust: 0,
        lastLocation: location,
        updatedAt: DateTime.now(),
      ),
    );

    await ensureDefaultMaintenanceItems(nextId);
    return nextId;
  }

  Future<String> getNextVehicleId() async {
    final vehicles = _vehicles;
    if (vehicles == null) {
      return 'V${_nextVehicleNumber(_localVehicles.keys) + 1}';
    }

    try {
      final snap = await vehicles.get();
      return 'V${_nextVehicleNumber(snap.docs.map((d) => d.id)) + 1}';
    } catch (_) {
      return 'V${_nextVehicleNumber(_localVehicles.keys) + 1}';
    }
  }

  int _nextVehicleNumber(Iterable<String> ids) {
    int maxNumber = 0;
    for (final rawId in ids) {
      final id = rawId.trim().toUpperCase();
      final match = RegExp(r'^V(\d+)$').firstMatch(id);
      if (match == null) continue;
      final number = int.tryParse(match.group(1) ?? '0') ?? 0;
      if (number > maxNumber) maxNumber = number;
    }
    return maxNumber;
  }

  Stream<List<Vehicle>> watchVehicles() {
    final vehicles = _vehicles;
    if (vehicles == null) {
      Future.microtask(_emitLocalVehicles);
      return _localVehiclesCtl.stream;
    }

    return vehicles.snapshots().map((snap) {
      final list = snap.docs.map((d) => _vehicleFromDoc(d)).toList();
      list.sort(
        (a, b) => _vehicleSortKey(a.id).compareTo(_vehicleSortKey(b.id)),
      );
      return list;
    });
  }

  ///

  Stream<List<DailyStat>> watchDailyUsage(String vehicleId) {
    final vehicles = _vehicles;
    if (vehicles == null) {
      return const Stream<List<DailyStat>>.empty();
    }

    return vehicles
        .doc(vehicleId)
        .collection('daily_usage')
        .orderBy('dayStart')
        .snapshots()
        .map((snapshot) {
          return snapshot.docs.map((doc) {
            final data = doc.data();
            final ts = data['dayStart'] as Timestamp?;
            final day = ts?.toDate().toLocal() ?? _parseDailyUsageDocId(doc.id);

            return DailyStat(
              day: DateTime(day.year, day.month, day.day),
              distanceKm: ((data['distanceKm'] ?? 0) as num).toDouble(),
              avgSpeedKmh: 0,
              maxSpeedKmh: 0,
            );
          }).toList();
        });
  }

  Stream<List<HistoryRouteRecord>> watchHistoryRoutes(
    String vehicleId, {
    int keepDays = 30,
  }) {
    final vehicles = _vehicles;
    if (vehicles == null) {
      return const Stream<List<HistoryRouteRecord>>.empty();
    }

    final keepFrom = DateTime.now().subtract(Duration(days: keepDays - 1));

    return vehicles
        .doc(vehicleId)
        .collection('history_routes')
        .where('startAt', isGreaterThanOrEqualTo: Timestamp.fromDate(keepFrom))
        .orderBy('startAt', descending: true)
        .snapshots()
        .map((snap) {
          return snap.docs.map((doc) {
            final m = doc.data();

            final rawPoints = (m['points'] as List?) ?? const [];
            final points = rawPoints.map((e) {
              final p = Map<String, dynamic>.from(e as Map);
              return LatLng(
                ((p['lat'] ?? 0) as num).toDouble(),
                ((p['lon'] ?? 0) as num).toDouble(),
              );
            }).toList();

            return HistoryRouteRecord(
              id: doc.id,
              vehicleId: (m['vehicleId'] ?? vehicleId).toString(),
              dayKey: (m['dayKey'] ?? '').toString(),
              startAt: (m['startAt'] as Timestamp).toDate(),
              endAt: m['endAt'] == null
                  ? null
                  : (m['endAt'] as Timestamp).toDate(),
              isClosed: (m['isClosed'] ?? false) as bool,
              startTotalKm: ((m['startTotalKm'] ?? 0) as num).toDouble(),
              endTotalKm: ((m['endTotalKm'] ?? 0) as num).toDouble(),
              distanceKm: ((m['distanceKm'] ?? 0) as num).toDouble(),
              points: points,
            );
          }).toList();
        });
  }

  Future<void> upsertDailyUsageFromOdo(
    Vehicle vehicle, {
    int keepDays = 30,
  }) async {
    final db = _db;
    final vehicles = _vehicles;

    if (db == null || vehicles == null) return;

    final localTime = vehicle.updatedAt.toLocal();
    final dayStart = DateTime(localTime.year, localTime.month, localTime.day);
    final dayKey = _dailyUsageDocId(dayStart);

    final docRef = vehicles
        .doc(vehicle.id)
        .collection('daily_usage')
        .doc(dayKey);

    await db.runTransaction((tx) async {
      final snap = await tx.get(docRef);
      final currentOdo = vehicle.totalKm;
      final expiresAt = dayStart.add(Duration(days: keepDays));

      if (!snap.exists) {
        tx.set(docRef, {
          'dayKey': dayKey,
          'dayStart': Timestamp.fromDate(dayStart),
          'startTotalKm': currentOdo,
          'endTotalKm': currentOdo,
          'distanceKm': 0.0,
          'lastSeenAt': Timestamp.fromDate(localTime),
          'expiresAt': Timestamp.fromDate(expiresAt),
        });
        return;
      }

      final data = snap.data() ?? <String, dynamic>{};
      final startKm = ((data['startTotalKm'] ?? currentOdo) as num).toDouble();
      final oldEndKm = ((data['endTotalKm'] ?? startKm) as num).toDouble();

      final nextEndKm = currentOdo > oldEndKm ? currentOdo : oldEndKm;
      final distanceKm = nextEndKm - startKm;

      tx.update(docRef, {
        'endTotalKm': nextEndKm,
        'distanceKm': distanceKm < 0 ? 0.0 : distanceKm,
        'lastSeenAt': Timestamp.fromDate(localTime),
        'expiresAt': Timestamp.fromDate(expiresAt),
      });
    });

    await pruneOldDailyUsage(vehicle.id, keepDays: keepDays);
  }

  Future<void> pruneOldDailyUsage(String vehicleId, {int keepDays = 30}) async {
    final db = _db;
    final vehicles = _vehicles;

    if (db == null || vehicles == null) return;

    final now = DateTime.now().toLocal();
    final keepFrom = DateTime(
      now.year,
      now.month,
      now.day,
    ).subtract(Duration(days: keepDays - 1));

    final query = await vehicles
        .doc(vehicleId)
        .collection('daily_usage')
        .where('dayStart', isLessThan: Timestamp.fromDate(keepFrom))
        .get();

    if (query.docs.isEmpty) return;

    final batch = db.batch();
    for (final doc in query.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }

  String _dailyUsageDocId(DateTime d) {
    final y = d.year.toString().padLeft(4, '0');
    final m = d.month.toString().padLeft(2, '0');
    final day = d.day.toString().padLeft(2, '0');
    return '$y-$m-$day';
  }

  DateTime _parseDailyUsageDocId(String id) {
    final parts = id.split('-');
    if (parts.length != 3) return DateTime.now();

    return DateTime(
      int.tryParse(parts[0]) ?? DateTime.now().year,
      int.tryParse(parts[1]) ?? DateTime.now().month,
      int.tryParse(parts[2]) ?? DateTime.now().day,
    );
  }

  ///

  Vehicle _vehicleFromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? <String, dynamic>{};
    final rawLastLocation = m['lastLocation'];
    final Map<String, dynamic> loc = rawLastLocation is Map<String, dynamic>
        ? rawLastLocation
        : <String, dynamic>{};

    final vehicleName = _asString(m['name']) ?? _asString(loc['name']) ?? d.id;
    final totalKm = _asDouble(m['totalKm']) ?? _asDouble(loc['totalKm']) ?? 0.0;
    final batteryPercent = _asInt(m['batteryPercent']) ?? 0;
    final isLocked = _asBool(m['isLocked']) ?? true;
    final isRunning = _asBool(m['isRunning']) ?? false;
    final lat = _asDouble(loc['lat']) ?? _asDouble(m['lat']) ?? 0.0;
    final lon = _asDouble(loc['lon']) ?? _asDouble(m['lon']) ?? 0.0;

    final rawUpdatedAt = m['updatedAt'];
    final updatedAt = rawUpdatedAt is Timestamp
        ? rawUpdatedAt.toDate()
        : DateTime.now();

    return Vehicle(
      id: d.id,
      name: vehicleName,
      batteryPercent: batteryPercent.clamp(0, 100).toInt(),
      isLocked: isLocked,
      isRunning: isRunning,
      totalKm: totalKm,
      temp: _asDouble(m['temp']) ?? 0.0,
      hum: _asDouble(m['hum']) ?? 0.0,
      dust: _asDouble(m['dust']) ?? 0.0,
      lastLocation: LatLng(lat, lon),
      updatedAt: updatedAt,
    );
  }

  int _vehicleSortKey(String id) {
    final match = RegExp(r'^(?:V|v)(\d+)$').firstMatch(id.trim());
    if (match == null) return 1 << 30;
    return int.tryParse(match.group(1) ?? '') ?? (1 << 30);
  }

  String? _asString(dynamic value) {
    if (value == null) return null;
    return value.toString();
  }

  double? _asDouble(dynamic value) {
    if (value == null) return null;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString());
  }

  int? _asInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value.toString());
  }

  bool? _asBool(dynamic value) {
    if (value == null) return null;
    if (value is bool) return value;
    final text = value.toString().trim().toLowerCase();
    if (text == 'true') return true;
    if (text == 'false') return false;
    return null;
  }

  Stream<List<MaintenanceItem>> watchMaintenance(String vehicleId) {
    final vehicles = _vehicles;
    if (vehicles == null) return const Stream<List<MaintenanceItem>>.empty();

    return vehicles
        .doc(vehicleId)
        .collection('maintenance')
        .snapshots()
        .map(
          (snap) => snap.docs
              .map((d) => MaintenanceItem.fromMap(d.id, d.data()))
              .toList(),
        );
  }

  Future<void> saveMaintenanceItem(String vehicleId, MaintenanceItem it) async {
    final vehicles = _vehicles;
    if (vehicles == null) return;

    await vehicles.doc(vehicleId).collection('maintenance').doc(it.id).set({
      'name': it.name,
      'maintanceKm': it.maintanceKm,
      'cycleKm': it.cycleKm,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> ensureDefaultMaintenanceItems(String vehicleId) async {
    final db = _db;
    final vehicles = _vehicles;
    if (db == null || vehicles == null) return;

    final ref = vehicles.doc(vehicleId).collection('maintenance');
    final snap = await ref.limit(1).get();
    if (snap.docs.isNotEmpty) return;

    final defaults = <MaintenanceItem>[
      const MaintenanceItem(
        id: 'oil',
        name: 'Thay nhớt',
        maintanceKm: 0,
        cycleKm: 2000,
      ),
      const MaintenanceItem(
        id: 'brake',
        name: 'Tra/Thay nhớt thắng',
        maintanceKm: 0,
        cycleKm: 4000,
      ),
      const MaintenanceItem(
        id: 'battery',
        name: 'Kiểm tra/Thay pin',
        maintanceKm: 0,
        cycleKm: 12000,
      ),
    ];

    final batch = db.batch();
    for (final item in defaults) {
      batch.set(ref.doc(item.id), {
        'name': item.name,
        'maintanceKm': item.maintanceKm,
        'cycleKm': item.cycleKm,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
    await batch.commit();
  }

  Future<void> incrementMaintenanceByDistance(
    String vehicleId,
    double deltaKm,
  ) async {
    if (deltaKm <= 0) return;

    final db = _db;
    final vehicles = _vehicles;
    if (db == null || vehicles == null) return;

    final ref = vehicles.doc(vehicleId).collection('maintenance');
    final snap = await ref.get();
    if (snap.docs.isEmpty) return;

    final batch = db.batch();
    for (final doc in snap.docs) {
      final data = doc.data();
      final current =
          _asDouble(data['maintanceKm']) ??
          _asDouble(data['maintenanceKm']) ??
          0.0;

      batch.set(doc.reference, {
        'maintanceKm': current + deltaKm,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
    await batch.commit();
  }

  Stream<List<Trip>> watchTrips(String vehicleId) {
    final vehicles = _vehicles;
    if (vehicles == null) return const Stream<List<Trip>>.empty();

    return vehicles.doc(vehicleId).collection('trips').snapshots().map((snap) {
      return snap.docs.map((d) {
        final m = d.data();
        final pts = (m['points'] as List<dynamic>? ?? [])
            .map(
              (p) => TripPoint(
                time:
                    DateTime.tryParse((p['time'] ?? '').toString()) ??
                    DateTime.now(),
                latLng: LatLng(
                  (p['lat'] ?? 0).toDouble(),
                  (p['lon'] ?? 0).toDouble(),
                ),
                speedKmh: (p['speedKmh'] ?? 0).toDouble(),
              ),
            )
            .toList();
        return Trip(
          id: d.id,
          vehicleId: vehicleId,
          startTime:
              DateTime.tryParse((m['startTime'] ?? '').toString()) ??
              DateTime.now(),
          endTime:
              DateTime.tryParse((m['endTime'] ?? '').toString()) ??
              DateTime.now(),
          points: pts,
        );
      }).toList();
    });
  }

  Future<void> saveTrip(String vehicleId, Trip t) async {
    final vehicles = _vehicles;
    if (vehicles == null) return;

    await vehicles.doc(vehicleId).collection('trips').doc(t.id).set({
      'startTime': t.startTime.toIso8601String(),
      'endTime': t.endTime.toIso8601String(),
      'distanceKm': t.distanceKm,
      'maxSpeedKmh': t.maxSpeedKmh,
      'avgSpeedKmh': t.avgSpeedKmh,
      'points': t.points
          .map(
            (p) => {
              'time': p.time.toIso8601String(),
              'lat': p.latLng.latitude,
              'lon': p.latLng.longitude,
              'speedKmh': p.speedKmh,
            },
          )
          .toList(),
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
}
